# Help Center Search App

This is a Help Center Search app. It can be used by agents to search articles and use the article search results to help them answer support tickets.

### The following information is displayed:

* Search Bar
* Results list


Please bear in mind that this is not a supported Zendesk app . It was developed to teach parts of the Apps Framework for the purposes of this course.

If you have any Zendesk Apps Framework questions please send an email to: support@zendesk.com
